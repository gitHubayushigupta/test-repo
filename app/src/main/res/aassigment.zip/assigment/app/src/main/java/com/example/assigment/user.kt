package com.example.assigment

data class User(val name:String,val uniqueId:String  , val password:String){

}
